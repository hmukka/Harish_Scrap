# CraiglistScraper
A scraper project to scrape information from Craiglist

#Description
It has functionality to search based location and search term.
Also search result can be exported as CSV.
