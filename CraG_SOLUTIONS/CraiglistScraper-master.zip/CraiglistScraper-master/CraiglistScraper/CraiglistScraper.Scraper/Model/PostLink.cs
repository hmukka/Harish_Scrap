﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CraiglistScraper.Scraper.Model
{
    public class PostLink
    {
        public string Title { get; set; }
        public string Url { get; set; }
    }
}
